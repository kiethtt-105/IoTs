# Hướng dẫn Smart Lock App (Android) — bản cải tiến

## Kiểm tra kết nối Backend + CSDL

Trên màn **Login**:
1. Bật **Cấu hình IP Backend + CSDL**
2. Nhập IP máy chạy backend (cùng WiFi), ví dụ `192.168.1.5`
3. Bấm **Kiểm tra kết nối Backend + CSDL**

App sẽ gọi `GET /health`:
- ✅ **Backend đang chạy** → uvicorn OK
- ❌ Timeout / connection error → sai IP, firewall, hoặc backend chưa start
- Sau khi đăng nhập, mọi lỗi HTTP 500 được hiểu là **PostgreSQL / CSDL** có vấn đề

### Checklist khi không kết nối được

| Triệu chứng | Nguyên nhân thường gặp | Cách xử lý |
|-------------|------------------------|------------|
| Timeout / connection error | Sai IP, khác WiFi, backend off | `uvicorn app.main:app --host 0.0.0.0 --port 8000` |
| HTTP 500 khi login/list | PostgreSQL chưa chạy hoặc sai `.env` | `net start postgresql-...` + kiểm tra `DATABASE_URL` |
| 401 | Sai email/password | Dùng `admin@admin.vn` / `admin123` |
| Devices trống | Chưa seed / chưa đăng ký khóa | Chạy `python seed.py` + simulator đăng ký device |

Database: **smart_lock** (PostgreSQL)  
Schema: `access_logs`, `devices`, `users`, ... (file `01_create_tables.sql`)

---

## Cài đặt nhanh

```bash
flutter create smart_lock_app
cd smart_lock_app
# Copy lib/ + pubspec.yaml từ zip vào

# Thêm permission vào android/app/src/main/AndroidManifest.xml:
# INTERNET, BLUETOOTH_SCAN, BLUETOOTH_CONNECT, ACCESS_FINE_LOCATION
# (xem android_notes/AndroidManifest_permissions.xml)

flutter pub get
flutter run
flutter build apk --release
```

## API khớp backend thật

| Endpoint | Dùng trong app |
|----------|----------------|
| `GET /health` | Kiểm tra kết nối |
| `POST /api/auth/login` | Đăng nhập → access_token + user |
| `GET /api/auth/me` | Khôi phục session |
| `GET /api/devices` | Danh sách khóa (đọc CSDL) |
| `POST /api/devices/{id}/command` | lock / unlock (MQTT + log) |
| `GET /api/logs` | AccessLogOut từ bảng access_logs |

## Hybrid điều khiển

1. BLE offline (MAC khóa) — ưu tiên  
2. Online API → MQTT → khóa  
3. BLE thành công + có mạng → vẫn ghi log lên CSDL  

## Tài khoản demo

- admin@admin.vn / admin123 (owner)
