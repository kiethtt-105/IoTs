# Smart Lock Mobile App (Android)

Hybrid BLE + Online cho hệ thống Smart Lock IoT.

## Tính năng

- Đăng nhập (JWT)
- Danh sách khóa + trạng thái real-time
- **Hybrid Control**:
  1. Ưu tiên **BLE offline** (tầm gần)
  2. Không được → fallback **Online** (API → MQTT)
  3. Có mạng + BLE → mở bằng BLE + đồng bộ log lên backend
- Giao diện dark mode đẹp

## Cài đặt nhanh

### 1. Cài Flutter (nếu chưa có)

```bash
# Windows: tải từ https://docs.flutter.dev/get-started/install/windows
# Sau đó:
flutter doctor
```

### 2. Tạo project & copy code

```bash
# Tạo project mới
flutter create smart_lock_app
cd smart_lock_app

# Xóa lib cũ, copy toàn bộ folder lib/ + pubspec.yaml từ repo này vào
# (hoặc clone/copy nguyên folder smart_lock_app)
```

### 3. Cài package

```bash
flutter pub get
```

### 4. Cấu hình IP Backend

Mở app → màn Login → bấm **"Cấu hình IP Backend"**  
Nhập IP máy đang chạy backend (ví dụ `192.168.1.5`)

> Lưu ý: Điện thoại và máy tính phải cùng WiFi.

### 5. Chạy app

```bash
# Kết nối điện thoại Android (bật USB Debugging) hoặc dùng emulator
flutter run
```

### 6. Build APK để cài ngoài

```bash
flutter build apk --release
```

File APK nằm ở:
```
build/app/outputs/flutter-apk/app-release.apk
```

Copy sang điện thoại → bật **Cài đặt từ nguồn không xác định** → cài.

---

## Tài khoản demo

| Email             | Password  | Role  |
|-------------------|-----------|-------|
| admin@admin.vn    | admin123  | owner|
| member@example.com| member123 | member|

## Device mẫu (từ simulator)

- **ID**: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`
- **MAC**: `AA:BB:CC:DD:EE:01`
- **Tên**: Khóa cửa chính

---

## Quyền Android cần thiết

App tự xin quyền:
- `BLUETOOTH_SCAN`
- `BLUETOOTH_CONNECT`
- `ACCESS_FINE_LOCATION` (bắt buộc cho BLE trên Android)

File `android/app/src/main/AndroidManifest.xml` cần có:

```xml
<uses-permission android:name="android.permission.BLUETOOTH"/>
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN"/>
<uses-permission android:name="android.permission.BLUETOOTH_SCAN"/>
<uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.INTERNET"/>
```

---

## Lưu ý về BLE

Hiện tại **sensor-simulator** chỉ giả lập BLE qua menu (không phát BLE thật).

Khi bạn làm khóa ESP32 thật:
- Service UUID: `0000fff0-0000-1000-8000-00805f9b34fb`
- Characteristic Command (Write): `0000fff1-...`
- Gửi JSON: `{"cmd":"unlock","ts":1234567890}`

App đã sẵn protocol này → chỉ cần ESP32 implement đúng là chạy được offline.

---

## Cấu trúc code

```
lib/
├── main.dart
├── core/
│   ├── api/api_client.dart      # Dio + JWT
│   ├── ble/ble_service.dart     # flutter_blue_plus
│   ├── models/                  # User, Device
│   ├── services/                # Auth, Device (hybrid), Ble
│   └── theme/app_theme.dart
└── features/
    ├── auth/login_page.dart
    ├── home/home_page.dart
    └── devices/device_detail_page.dart
```

---

## Roadmap (iOS sau)

- Thêm platform iOS
- Push notification (FCM)
- Enroll thẻ NFC từ app
- Lịch sử truy cập chi tiết
